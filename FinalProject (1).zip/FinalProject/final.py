import random
import math

class H:
    perfectH = [1, 0, 1, 1, 1, 1, 1, 0 ,1 ,1, 0, 1]
    Harr = []
    def getH(self, arrVal, Hval):
        self.Harr = Hval
        for i in arrVal:
            self.Harr[self.binaryToDecimal(i)] = self.Harr[self.binaryToDecimal(i)] + 1
        return self.Harr

    # Received this function from https://www.geeksforgeeks.org/binary-decimal-vice-versa-python/
    # This function helps us convert binary to decimal
    def binaryToDecimal(self, binary): 
        binary1 = binary 
        decimal, i, n = 0, 0, 0
        while(binary != 0): 
            dec = binary % 10
            decimal = decimal + dec * pow(2, i) 
            binary = binary//10
            i += 1
        return decimal  

class L:
    perfectL = [1, 0, 0, 1, 0, 0, 1, 0 ,0 ,1, 1, 1] 
    Larr = []
    def getL(self, arrVal, Lval):
        self.Larr = Lval
        for i in arrVal:
            self.Larr[self.binaryToDecimal(i)] = self.Larr[self.binaryToDecimal(i)] + 1
        return self.Larr
    def binaryToDecimal(self, binary): 
        binary1 = binary 
        decimal, i, n = 0, 0, 0
        while(binary != 0): 
            dec = binary % 10
            decimal = decimal + dec * pow(2, i) 
            binary = binary//10
            i += 1
        return decimal  


def getHorL(dataValArr, perfectH, perfectL, diffH, diffL):
    for idx, val in enumerate(dataValArr):
            if(perfectH[idx] is not val):
                diffH += 1
            if(perfectL[idx] is not val):
                diffL += 1
    if(diffH > diffL):
        return [dataValArr, 'L']
        Lsize += 1
    elif(diffH < diffL):
        return [dataValArr, 'H']
    else:
        if(Hsize > Lsize):
            return [dataValArr, 'L']
        else:
            return [dataValArr, 'H']

def getLorNot(dataValArr, perfectL):
    diff = 0
    for idx, val in enumerate(dataValArr):
        if(dataValArr[idx] is not perfectL[idx]):
            diff += 1
    if(diff >= 4):
        return False
    return True  

def getHorNot(dataValArr, perfectH):
    diff = 0
    for idx, val in enumerate(dataValArr):
        if(dataValArr[idx] is not perfectH[idx]):
            diff += 1
    if(diff >= 4):
        return False
    return True  

# Recieved this function from https://www.geeksforgeeks.org/python-convert-a-list-into-a-tuple/
# This function helps us convert a list to a tuple for the dataset
def convert(list): 
    return tuple(i for i in list) 

# Recieved this function from https://stackoverflow.com/questions/27427067/python-how-to-check-if-an-item-was-added-to-a-set-without-2x-hash-lookup
# This function helps us understand whether we are adding something to a set of not
def do_add(s, x):
  return len(s) != (s.add(x) or len(s))

def createDataSet():
    trainingDataSet = set()
    print("size is ", len(trainingDataSet))
    Hsize = 0
    Lsize = 0
    hval = H()
    lval = L()
    perfectH = hval.perfectH
    perfectL = lval.perfectL
    while(Hsize < 200 or Lsize < 200):
        dataVal = ()
        dataValArr = []
        diffH = 0
        diffL = 0
        for i in range(0, 12):
            randVal = random.randint(0, 1)
            dataValArr.append(randVal)
        if(Lsize < 200):
            if(getLorNot(dataValArr, perfectL) == True and not convert([convert(dataValArr), 'L']) in trainingDataSet):
                trainingDataSet.add(convert([convert(dataValArr), 'L']))
                Lsize = Lsize + 1
        elif(Hsize < 200):
            if(getHorNot(dataValArr, perfectH) == True and not convert([convert(dataValArr), 'H']) in trainingDataSet):
                    trainingDataSet.add(convert([convert(dataValArr), 'H']))
                    Hsize += 1
    with open('data.txt', 'a') as f:
        for item in trainingDataSet:
            arrVal = list(item[0])
            val = [arrVal, item[1]]
            f.write("%s\n" % val)
    return trainingDataSet

def createTestDataSet():
    testDataSet = set()
    Hsize = 0
    Lsize = 0
    hval = H()
    lval = L()
    perfectH = hval.perfectH
    perfectL = lval.perfectL
    while(Hsize < 100 or Lsize < 100):
        dataVal = ()
        dataValArr = []
        diffH = 0
        diffL = 0
        for i in range(0, 12):
            randVal = random.randint(0, 1)
            dataValArr.append(randVal)
        if(Lsize < 200):
            if(getLorNot(dataValArr, perfectL) == True and not convert([convert(dataValArr), 'L']) in testDataSet):
                testDataSet.add(convert([convert(dataValArr), 'L']))
                Lsize = Lsize + 1
        elif(Hsize < 200):
            if(getHorNot(dataValArr, perfectH) == True and not convert([convert(dataValArr), 'H']) in testDataSet):
                    testDataSet.add(convert([convert(dataValArr), 'H']))
                    Hsize += 1
    with open('data.txt', 'a') as f:
        for item in testDataSet:
            arrVal = list(item[0])
            val = [arrVal, item[1]]
            f.write("%s\n" % val)
    return testDataSet

def Jgenerator(n, m):
    J = set()
    for i in range(1, m+1):
        arr = []
        for i in range(1, n+1):
            value = random.randint(1, 12)
            arr.append(value)
            if(i == n):
                arr = tuple(arr)
                J.add(arr)
    return J

def getArr(J, arr, n):
    output = []
    for setVal in J: 
        strVal = ""
        for idx, val in enumerate(setVal):
            strVal += str(arr[val-1])
            if(idx+1 == n):
                output.append(int(strVal))
    return output

def arrDefault(n):
    output = []
    for i in range(0, 2**n):
        output.append(0)
    return output
        
def getArrays(Jval, testingDataSet, n):
    arr = []
    for setVal in Jval:
        arrVal = arrDefault(n)
        for i in testingDataSet:
            strVal = ""
            output = []
            for idx, val in enumerate(setVal):
                strVal += str(i[val-1])
                if(idx+1 == n):
                    dec = binaryToDecimal(int(strVal))
                    arrVal[dec] = arrVal[dec] + 1
        arr.append(arrVal)  
    return arr

def testFunction(Jval, H, L, test, n):
    sumH = 0
    sumL = 0
    for idxSet, setVal in enumerate(Jval):
        strVal = ""
        output = []
        for idx, val in enumerate(setVal):
            strVal += str(test[val-1])
            if(idx+1 == n):
                dec = binaryToDecimal(int(strVal))
                # print(H)
                sumH += H[idxSet][dec]
                sumL += L[idxSet][dec]
    if(sumH > sumL):
        return "H"
    elif(sumL > sumH):
        return "L"
    else:
        return "Tie"

                    
def getTrainingData():
    output = []
    with open('data.txt', 'r') as f:
        x = f.readlines()
        for i in x:
            listVal = i.strip('\\n').rsplit(',', 2)
            if('Train' in listVal[2]):
                arrVal = []
                for i in listVal[0]:
                    if(i == '1'):
                        arrVal.append(1)
                    elif(i == '0'):
                        arrVal.append(0)
                classVal = listVal[1][2:-1]
                output.append([arrVal, classVal])
    return output

def getTestData():
    output = []
    with open('data.txt', 'r') as f:
        x = f.readlines()
        for i in x:
            listVal = i.strip('\n').rsplit(',', 2)
            if('Test' in listVal[2]):
                arrVal = []
                for i in listVal[0]:
                    if(i == '1'):
                        arrVal.append(1)
                    elif(i == '0'):
                        arrVal.append(0)
                classVal = 'L'
                if('H' in listVal[1]):
                    classVal = 'H'
                output.append([arrVal, classVal])
    return output

def binaryToDecimal(binary): 
        binary1 = binary 
        decimal, i, n = 0, 0, 0
        while(binary != 0): 
            dec = binary % 10
            decimal = decimal + dec * pow(2, i) 
            binary = binary//10
            i += 1
        return decimal  

def main():    
    # createDataSet()
    # createTestDataSet()
    n = 3
    m = 50
    Jval = Jgenerator(n, m)
    trainData = getTrainingData()
    testData = getTestData()
    HTrainDataSet = []
    LTrainDataSet = []
    Hval = H()
    Lval = L()
    Harr = arrDefault(n)
    Larr = arrDefault(n)
    for i in trainData:
        if(i[1] is 'H'):
            arrVal = getArr(Jval, i[0], n)
            Harr = Hval.getH(arrVal, Harr)
            HTrainDataSet.append(i[0])
        else:
            arrVal = getArr(Jval, i[0], n)
            Larr = Lval.getL(arrVal, Larr)
            LTrainDataSet.append(i[0])
    diff = 0
    Hval = getArrays(Jval, HTrainDataSet, n)
    Lval = getArrays(Jval, LTrainDataSet, n)
    for i in testData:
        print(i, "Actual Class: ", i[1], "Predicted Class:", testFunction(Jval, Hval, Lval, i[0], n), i[1] in testFunction(Jval, Hval, Lval, i[0], n))
        if(i[1] not in testFunction(Jval, Hval, Lval, i[0], n)):
            diff = diff + 1
    percentage = float((float(200-diff))/200)*100
    print('Accuracy', str(percentage)+'%')

main()
